package model;


public class LightCycle extends Mobile {
	
	private int speed = 4;
	private int player;

	public LightCycle(Direction direction, Position position, int speed) {
		super(direction, position, speed);
		this.player = player;
	}
	
	public boolean isPlayerAlive(int player){
		return this.player == player;
	}
	
	public boolean hit(){
		// on remove le joueur egalement (potentiellement utilisable pour savoir le vainqueur)
		return true;
	}

}
