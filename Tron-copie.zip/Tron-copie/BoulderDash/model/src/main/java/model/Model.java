package model;

import java.util.ArrayList;

public class Model {

	private ArrayList<Integer> paths;
	
	public Model(){
		this.paths = new ArrayList<>();
	}
	
	
	/**
	 * pour le futur : rajouter les paramètre pour les ajouter dans le tableau
	 */
	public void addPath(){
	//	this.paths.add(path);
	}
	
	
	/**
	 * Pareil ici rajouter paramètre (je sais pas si encore besoin)
	 */
	public void removePath(){
	//	this.paths.remove(path);
	}
	
	public ArrayList<Integer> getPaths(){
		return this.paths;
	}

	/**
	 * Je sais pas encore quoi mettre dedans mais retourne le chemin d'un des joueur (avec le paths d'avant) (servira pour la collision normalement)
	 * @param player prend en paramètre le joueur 1 ou 2
	 * @return null
	 */
	public IMobile getPathPlayer(int player){
		return null;
	
	}
}
