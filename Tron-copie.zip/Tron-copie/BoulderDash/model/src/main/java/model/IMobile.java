package model;

/**
 * Interface pour tout ce qui sera mobile
 * permet d'avoir la direction et de la "setter"
 * permet d'avoir la position 
 * permet d'avoir une vitesse constante
 * permet de verifier si le joueur est en vie 
 * permet de verifier si on touche le mur (methode de collision dans le controller)
 * @author aymeric
 *
 */

public interface IMobile {

	public Direction getDirection();

	public void setDirection(final Direction direction);

	public Position getPosition();
	

	public int getSpeed();
	
	public void move();
	
	public boolean isPlayerAlive(int player);
	
	public boolean hitWall();

}
