package model;

/**
 * Classe de base qui indique la direction, position et la vitesse de chaque joueur
 * @author aymeric
 *
 */

public class Mobile implements IMobile{
	private Direction direction;
	private Position position;
	private int speed;
	
	public Mobile(Direction direction, Position position, int speed){
		this.direction = direction;
		this.position = position;
		this.speed = speed;
		
	}
/**
 * Getters et setters des direction, position , vittesse
 */
	@Override
	public Direction getDirection() {
		return this.direction;
	}

	@Override
	public void setDirection(Direction direction) {
		this.direction = direction;
		
	}

	@Override
	public Position getPosition() {
		return this.position;
	}


	@Override
	public int getSpeed() {
		return this.speed;
	}

	/**
	 * Methode permettant de se deplacer suivant la touche appyuer
	 */
	@Override
	public void move() {
		switch (this.direction) {
			case UP:
				this.moveUp();
				break;
			case RIGHT:
				this.moveRight();
				break;
			case DOWN:
				this.moveDown();
				break;
			case LEFT:
				this.moveLeft();
				break;
			default:
				break;
		}
	}
	
	/**
	 * Toute les methodes qui vont deplacer les objets 
	 */
	private void moveUp() {
		this.position.setY1(this.position.getY1() - this.speed);
	}

	private void moveRight() {
		this.position.setX1(this.position.getX1() + this.speed);
	}

	private void moveDown() {
		this.position.setY1(this.position.getY1() + this.speed);
	}

	private void moveLeft() {
		this.position.setX1(this.position.getX1() - this.speed);
	}

	
	@Override
	public boolean isPlayerAlive(int player) {
		return true;
	}

	@Override
	public boolean hitWall() {
		
		return true;
	}

}
