package model;

import java.util.ArrayList;

/**
 * Interface pour le model et non la bdd
 * permet d'ajouter le chemin des murs créer
 * permet d'enlever le chemin 
 * permet d'avoir le chemin dans un tableau
 * permet d'avoir un chemin pour chaque joueur
 * @author aymeric
 *
 */
public interface IModel2 {

	public void addPath();
	public void removePath(); 
	public ArrayList<Integer> getPaths();
	public IMobile getPathPlayer(int player);
}
