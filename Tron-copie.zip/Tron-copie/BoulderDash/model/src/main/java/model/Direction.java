package model;


/**
 * Enumeraction des direction possible
 * @author aymeric
 *
 */
public enum Direction {
	 UP, DOWN,RIGHT, LEFT
}
