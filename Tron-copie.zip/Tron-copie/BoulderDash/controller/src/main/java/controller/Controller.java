package controller;


import model.Direction;
import model.IMobile;
import model.IModel2;
import view.IView2;



public class Controller implements IOrderPerformer{
	
	private  IModel2 model;
	private IView2 view;
	
	
	
	public Controller(IModel2 model){
		this.model = model;
	}

	/**
	 * Donne l'info au model de quel touche est appyuer et donne la direction associé
	 */
	@Override
	public void orderPerform(IUser user) {
		if (user != null){
			IMobile player = this.model.getPathPlayer(user.getPlayer());
			if (player != null){
				Direction direction;
				switch (user.getOrder()) {
					case UP:
						direction = Direction.UP;
						break;
					case RIGHT:
						direction = Direction.RIGHT;
						break;
					case DOWN:
						direction = Direction.DOWN;
						break;
					case LEFT:
						direction = Direction.LEFT;
						break;
					default:
						direction = Direction.UP;
						break;					
			}
				player.setDirection(direction);		
			
		}
		
	}

}
	
	/**
	 * Methode IMPORTANTE qui va coincider chaque chemin de chaque joueur pour verifier l'obstacle
	 * le chemin se fera dans un tableau
	 * check si x1/x2 ou x1/y1 ou x1/y2 (ainsi de suite) se retouvent sur la meme case
	 */
	public void Collision(){
		
	}
	
	/**
	 * Permetera de lancer correctement la vue grace a une interface
	 */
	public void play(){
		this.view.run();
	}
}

