package controller;

/**
 * Enumeration exactement pareil que dans le model
 * @author aymeric
 *
 */
public enum Ordre {

	UP, RIGHT, DOWN, LEFT
}
