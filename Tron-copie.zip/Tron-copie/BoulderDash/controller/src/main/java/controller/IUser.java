package controller;

/**
 * Permet d'avoir le joueur 1 ou 2
 * Permet de savoir quel direction ils ont
 * @author aymeric
 *
 */
public interface IUser {

	int getPlayer();

	Ordre getOrder();
}
