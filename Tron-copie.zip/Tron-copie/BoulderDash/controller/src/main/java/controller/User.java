package controller;

/**
 * Permet d'avoir le joueur et la direction associer
 * @author aymeric
 *
 */
public class User implements IUser{
	private  int		player;
	private  Ordre	ordre;

	public User( int player,  Ordre ordre) {
		this.player = player;
		this.ordre = ordre;
	}
	
	@Override
	public int getPlayer() {
		return this.player;
	}

	@Override
	public Ordre getOrder() {
		return this.ordre;
	}

}
