package controller;


public interface IOrderPerformer {

	public void orderPerform( IUser user);
}
