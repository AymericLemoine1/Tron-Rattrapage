package model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import model.Direction;
import model.Mobile;

public class MobileTest {
	private Mobile mobile;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * Set up du mobile
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		Direction LEFT = null;
		this.mobile = new Mobile (LEFT, null, 3);
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * tests des getters et du setter
	 */
	@Test
	public void testGetDirection() {
		final Direction expected = null;
		assertEquals(expected, this.mobile.getDirection());
	}
	
	@Test
	public void testSetDirection(){
		Direction expected = null;
		assertEquals(expected, this.mobile.getDirection());
		expected = null;
		this.mobile.setDirection(expected);
		assertEquals(expected, this.mobile.getDirection());
	}
	
	@Test
	public void testGetSpeed(){
		int expected = 3;
		assertEquals(expected, this.mobile.getSpeed());
		
	}

}
