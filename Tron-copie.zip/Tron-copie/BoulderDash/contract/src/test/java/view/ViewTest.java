package view;

import static org.junit.Assert.*;

import java.awt.Frame;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import controller.IOrderPerformer;
import view.IEventPerformer;
//import view.View;




public class ViewTest {
	private  IEventPerformer	eventPerformer;
	private Frame frame;
	//private View view;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		IOrderPerformer eventPerformer = null;
		//this.view = new View(eventPerformer);
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test pour afficher la fenetre 
	 */
	@Test
	public void testRun() {
		this.frame = new Frame();
	}

}
