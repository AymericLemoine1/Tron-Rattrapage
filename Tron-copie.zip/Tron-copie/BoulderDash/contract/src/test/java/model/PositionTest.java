package model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import model.Position;

public class PositionTest {
	
	private Position position;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * set up de la position 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		this.position = new Position(30, 30, 300, 300);
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * tests sur les getters et setters 
	 */
	@Test
	public void testgetX1() {
		final int expected = 30;
		assertEquals(expected, this.position.getX1());
	}
	
	@Test
	public void testGetY1(){
		final int expected = 30;
		assertEquals(expected, this.position.getY1());
	}
	
	@Test
	public void testGetX2(){
		final int expected = 300;
		assertEquals(expected, this.position.getX2());
	}

	@Test
	public void testGetY2(){
		final int expected = 300;
		assertEquals(expected, this.position.getY2());
	}
	
	@Test
	public void testSetX1(){
		int expected = 30;
		assertEquals(expected, this.position.getX1());
		expected = 33;
		this.position.setX1(expected);
		assertEquals(expected, this.position.getX1());
		
	}
	@Test
	public void testSetY1(){
		int expected = 30;
		assertEquals(expected, this.position.getY1());
		expected = 33;
		this.position.setY1(expected);
		assertEquals(expected, this.position.getY1());
		
	}
	
	@Test
	public void testSetX2(){
		int expected = 300;
		assertEquals(expected, this.position.getX2());
		expected = 303;
		this.position.setX2(expected);
		assertEquals(expected, this.position.getX2());
	}
	
	@Test
	public void testSetY2(){
		int expected = 300;
		assertEquals(expected, this.position.getY2());
		expected = 303;
		this.position.setY2(expected);
		assertEquals(expected, this.position.getY2());
		
	}
}
