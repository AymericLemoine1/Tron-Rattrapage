package model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import model.Example;

public class RequeteDAOTest {
	private Example example;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	
	/**
	 * Set up de la bdd
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		this.example = new Example(1, null);
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * test pour verifier que l'id sera bien 1
	 */
	@Test
	public void getTimerTest() {
		final int expected = 1;
        assertEquals(expected, this.example.getId());
	}

}
