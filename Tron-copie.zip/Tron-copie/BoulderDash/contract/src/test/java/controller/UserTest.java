package controller;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import controller.Ordre;
import controller.User;

public class UserTest {
	private User user;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * Set up de user
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		Ordre ordre= null;
		this.user = new User(0, ordre);
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Getters de user
	 */
	@Test
	public void testGetPlayer() {
		int expected =0;
		assertEquals(expected, this.user.getPlayer());
	}
	
	@Test
	public void testGetOrdre(){
		Ordre expected = null;
		assertEquals(expected, this.user.getOrder());
		
	}

}
