package model;

public interface IMobile {

	public Direction getDirection();

	public void setDirection(final Direction direction);

	public Position getPosition();
	

	public int getSpeed();
	
	public void move();
	
	public boolean isPlayerAlive(int player);
	
	public boolean hitWall();
}
