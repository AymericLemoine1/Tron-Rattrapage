package model;

import java.util.ArrayList;

public interface IModel2 {

	public void addPath();
	public void removePath(); 
	public ArrayList<Integer> getPaths();
	public IMobile getPathPlayer(int player);
}
