package controller;

public interface IUser {

	int getPlayer();

	Ordre getOrder();
}
