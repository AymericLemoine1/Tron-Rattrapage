package controller;

public enum Ordre {

	UP, RIGHT, DOWN, LEFT
}
