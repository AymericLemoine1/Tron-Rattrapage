package view;

import java.awt.event.KeyEvent;

public interface IEventPerformer {
	public void eventPerform(KeyEvent keyCode);
}
