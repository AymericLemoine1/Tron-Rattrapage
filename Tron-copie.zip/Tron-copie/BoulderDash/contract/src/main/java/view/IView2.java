package view;

public interface IView2 {

	public void run();
}
