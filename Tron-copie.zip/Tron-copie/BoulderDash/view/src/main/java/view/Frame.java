package view;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;


public class Frame extends JFrame implements KeyListener{
	
	private  IEventPerformer eventPerformer;
	
	/**
	 * Initialise la frame
	 * @param eventPerformer  via une interface
	 */
	public Frame(IEventPerformer eventPerformer){
		this.eventPerformer = eventPerformer;
		
		this.setTitle("tron");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600, 400);
		Paint rect = new Paint();
		this.add(rect);
		this.addKeyListener(this);
		this.setVisible(true);
	}
	
	
	/**
	 * Methode de KeyListener, on recupere la touche appuyer
	 */
	@Override
		public void keyPressed(KeyEvent keyEvent) {
			this.eventPerformer.eventPerform(keyEvent);
	}
	
	/**
	 * Methode de Keylistener
	 */
	@Override
	public void keyTyped(KeyEvent keyEvent) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * Methode de KeyListener
	 */
	@Override
	public void keyReleased(KeyEvent keyEvent) {
		// TODO Auto-generated method stub
		
	}

}
