package view;

import java.awt.event.KeyEvent;


/**
 * Interface de eventPerformer
 * @author aymeric
 *
 */
public interface IEventPerformer {
	public void eventPerform(KeyEvent keyCode);
}
