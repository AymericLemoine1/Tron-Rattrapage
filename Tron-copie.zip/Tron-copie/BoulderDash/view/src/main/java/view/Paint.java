package view;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class Paint extends JPanel {

	/**
	 * changer les x et Y pour pouvoir les faires bouger via le controller puis le model qui modifie les valeurs 
	 * je les laisse juste pour montrer lors de la demo
	 */
	public void paintComponent(Graphics g){
		super.paintComponents(g);
		
		// set background
		setBackground (Color.BLACK);
		
		// Player 1
		g.setColor(Color.GREEN);
		g.fillRect(30, 30, 15, 15);
		
		
		//Player 2
		g.setColor(Color.RED);
		g.fillRect(300, 300, 15, 15);
	}
}
