package view;

import java.awt.event.KeyEvent;

import controller.IOrderPerformer;
import controller.IUser;
import controller.Ordre;
import controller.User;


public class EventPerformer implements IEventPerformer {
	private IOrderPerformer orderPerformer;

	/**
	 * Constructeur permettant de "comuniquer" avec le controller
	 * @param orderPerformer permet de "communiquer" avec le controller
	 */
	public EventPerformer(IOrderPerformer orderPerformer){
		this.orderPerformer = orderPerformer;
	}
	
	/**
	 * Permet d'avoir le keyCode du joueur 
	 */
	@Override
	public void eventPerform(KeyEvent keyCode) {
		IUser user = this.keyCodeUser(keyCode.getKeyCode());
		if (user != null)		
			this.orderPerformer.orderPerform(user);
	}
	
	
	/**
	 * Permet d'assigner chaque touche a un joueur 
	 * @param keyCode permet d'avoir le code de la touche utiliser
	 * @return
	 */
	private IUser keyCodeUser(int keyCode){
		IUser user;
		switch(keyCode){
		case KeyEvent.VK_UP:
			user = new User(0, Ordre.UP);
			break;
		case KeyEvent.VK_RIGHT:
			user = new User(0, Ordre.RIGHT);
			break;
		case KeyEvent.VK_DOWN:
			user = new User(0, Ordre.DOWN);
			break;
		case KeyEvent.VK_LEFT:
			user = new User(0, Ordre.LEFT);
			break;

		case KeyEvent.VK_Z:
			user = new User(1, Ordre.UP);
			break;
		case KeyEvent.VK_D:
			user = new User(1, Ordre.RIGHT);
			break;
		case KeyEvent.VK_S:
			user = new User(1, Ordre.DOWN);
			break;
		case KeyEvent.VK_Q:
			user = new User(1, Ordre.LEFT);
			break;
		
		default:
			user = null;
	}
	return user;

		}
	}


