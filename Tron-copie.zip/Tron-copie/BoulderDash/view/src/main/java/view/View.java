package view;

import controller.IOrderPerformer;

public class View implements IView2{
	
	private  EventPerformer	eventPerformer;
	private Frame frame;
	
	/**
	 * Instancie les événements grace notament au controller
	 * @param orderPerformer via une interface
	 */
	public View( IOrderPerformer orderPerformer){
		this.eventPerformer = new EventPerformer(orderPerformer);
		
	}
	
	/**
	 * Permet de lancer la frame 
	 */
	public void run() {
		this.frame = new Frame( this.eventPerformer);
	}
}
